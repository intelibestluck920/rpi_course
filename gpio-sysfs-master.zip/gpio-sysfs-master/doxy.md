# Raspberry PI GPIO communication via sysfs

SysGPIO is a class which encapsulate the
reading / writing and interrupt handling to/from GPIO pins
of the raspberry pi.

## github

https://github.com/berndporr/gpio-sysfs
