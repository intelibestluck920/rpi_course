var classADS1115rpi =
[
    [ "~ADS1115rpi", "classADS1115rpi.html#a3dec47dc3242290468f21396df0d71a5", null ],
    [ "hasSample", "classADS1115rpi.html#a515633c671efe89d43b814d4682440af", null ],
    [ "setChannel", "classADS1115rpi.html#a4f36d0cca6cbec106b5a626d9973e091", null ],
    [ "start", "classADS1115rpi.html#a401e626b6afed688a9b0518c0316b2a9", null ],
    [ "stop", "classADS1115rpi.html#a910b9735f8bef69a0844a821fda06baf", null ]
];