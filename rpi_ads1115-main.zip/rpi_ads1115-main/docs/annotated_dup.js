var annotated_dup =
[
    [ "ADS1115rpi", "classADS1115rpi.html", "classADS1115rpi" ],
    [ "ADS1115settings", "structADS1115settings.html", "structADS1115settings" ]
];