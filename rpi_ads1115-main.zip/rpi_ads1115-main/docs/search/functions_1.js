var searchData=
[
  ['setchannel_21',['setChannel',['../classADS1115rpi.html#a4f36d0cca6cbec106b5a626d9973e091',1,'ADS1115rpi']]],
  ['start_22',['start',['../classADS1115rpi.html#a401e626b6afed688a9b0518c0316b2a9',1,'ADS1115rpi']]],
  ['stop_23',['stop',['../classADS1115rpi.html#a910b9735f8bef69a0844a821fda06baf',1,'ADS1115rpi']]]
];
