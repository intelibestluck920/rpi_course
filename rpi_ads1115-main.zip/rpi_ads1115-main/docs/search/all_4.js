var searchData=
[
  ['i2c_5fbus_6',['i2c_bus',['../structADS1115settings.html#ae0f3b1d6ef8068fed5e580fd4d7123b3',1,'ADS1115settings']]],
  ['initpigpio_7',['initPIGPIO',['../structADS1115settings.html#add939ea3e172fc3c52fe9e53b05a66e4',1,'ADS1115settings']]],
  ['input_8',['Input',['../structADS1115settings.html#a17845a1a94f94bb7d2406dbe13bc560d',1,'ADS1115settings']]]
];
