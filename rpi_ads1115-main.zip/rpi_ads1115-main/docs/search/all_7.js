var searchData=
[
  ['samplingrate_12',['samplingRate',['../structADS1115settings.html#aab5ef57bb9aef08aac7a7fd7de33a451',1,'ADS1115settings']]],
  ['samplingrates_13',['SamplingRates',['../structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357',1,'ADS1115settings']]],
  ['setchannel_14',['setChannel',['../classADS1115rpi.html#a4f36d0cca6cbec106b5a626d9973e091',1,'ADS1115rpi']]],
  ['start_15',['start',['../classADS1115rpi.html#a401e626b6afed688a9b0518c0316b2a9',1,'ADS1115rpi']]],
  ['stop_16',['stop',['../classADS1115rpi.html#a910b9735f8bef69a0844a821fda06baf',1,'ADS1115rpi']]]
];
