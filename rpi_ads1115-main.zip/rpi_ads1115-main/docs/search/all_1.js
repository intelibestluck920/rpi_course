var searchData=
[
  ['channel_3',['channel',['../structADS1115settings.html#a3f4f9b2d8b6f0ef724bd4e4a68b75245',1,'ADS1115settings']]]
];
