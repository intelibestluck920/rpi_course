var searchData=
[
  ['samplingrates_34',['SamplingRates',['../structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357',1,'ADS1115settings']]]
];
