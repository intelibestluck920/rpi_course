var structADS1115settings =
[
    [ "Input", "structADS1115settings.html#a17845a1a94f94bb7d2406dbe13bc560d", [
      [ "AIN0", "structADS1115settings.html#a17845a1a94f94bb7d2406dbe13bc560daa087ea46f630c382cfbe6b9e74a93956", null ],
      [ "AIN1", "structADS1115settings.html#a17845a1a94f94bb7d2406dbe13bc560dabce94db830ae8bd98155120296d43187", null ],
      [ "AIN2", "structADS1115settings.html#a17845a1a94f94bb7d2406dbe13bc560dab4ed82e9f524b9cd347fa8878afcf49c", null ],
      [ "AIN3", "structADS1115settings.html#a17845a1a94f94bb7d2406dbe13bc560daf41398bedce7b5ce208abf29e788ba92", null ]
    ] ],
    [ "PGA", "structADS1115settings.html#a831970032a15754ead970931dd25ac5f", [
      [ "FSR2_048", "structADS1115settings.html#a831970032a15754ead970931dd25ac5fa219c056740c23deafea320ee522d56cf", null ],
      [ "FSR1_024", "structADS1115settings.html#a831970032a15754ead970931dd25ac5fa54314fc0ed922c14c11f8a62beec0fe4", null ],
      [ "FSR0_512", "structADS1115settings.html#a831970032a15754ead970931dd25ac5faa52ee8e28cfbc6882b5fb52fcfaf049b", null ],
      [ "FSR0_256", "structADS1115settings.html#a831970032a15754ead970931dd25ac5fa66050b0b2dfa108d0fe262c156ee12dc", null ]
    ] ],
    [ "SamplingRates", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357", [
      [ "FS8HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357a571876b8fe1fcbf0ca6d5f7c22a86ec1", null ],
      [ "FS16HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357a2f16253b2ddb36688da0d2c9d6c37e73", null ],
      [ "FS32HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357afc33391b2dd7bb507a840155c6cfbd95", null ],
      [ "FS64HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357aaa99d6e592baaa5d271f24908249c0a7", null ],
      [ "FS128HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357a3265d07f32b61328f3ded165f8cb8fbc", null ],
      [ "FS250HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357a6a05f905cc2f142d9855ae13a925e296", null ],
      [ "FS475HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357a7fea2393497d03736ca6bf96b3ae55b2", null ],
      [ "FS860HZ", "structADS1115settings.html#aa3a33d5f6c7f14bb708a70499a225357a84398c434b3b9427990fafb9fae98093", null ]
    ] ],
    [ "address", "structADS1115settings.html#a5aac9fb517c9665aeca60f1a9b0bbbe2", null ],
    [ "channel", "structADS1115settings.html#a3f4f9b2d8b6f0ef724bd4e4a68b75245", null ],
    [ "drdy_gpio", "structADS1115settings.html#a2ec35347e84e5165a35191e670c05b79", null ],
    [ "i2c_bus", "structADS1115settings.html#ae0f3b1d6ef8068fed5e580fd4d7123b3", null ],
    [ "initPIGPIO", "structADS1115settings.html#add939ea3e172fc3c52fe9e53b05a66e4", null ],
    [ "pgaGain", "structADS1115settings.html#a9c5013fdbef7376faec2df49d123e67e", null ],
    [ "samplingRate", "structADS1115settings.html#aab5ef57bb9aef08aac7a7fd7de33a451", null ]
];