# I2C LSM9DS1 RaspberryPI C++ Library

This is a C++11 library for the LSM9DS1 on a Raspberry PI using a callback handler for the data.

[github repository](https://github.com/berndporr/LSM9DS1_RaspberryPi_CPP_Library)
