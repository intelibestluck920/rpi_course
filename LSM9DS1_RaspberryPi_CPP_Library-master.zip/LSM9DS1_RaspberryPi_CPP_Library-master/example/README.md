# Hardware

Pin assignment is below: 

|RasPi|LSM9DS1|
|:-:|:-:|
|GND|GND|
|3.3VDC Power|VDD|
|Pin3|SDA|
|Pin5|SCL|
|Pin15 (GPIO22)|INT2|

# How to run

```
sudo ./LSM9DS1_demo
```
