var searchData=
[
  ['m_5fscale_5f12gs_49',['M_SCALE_12GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937af5a22d2dff6ca6006a6bda427fd7b8ff',1,'MagSettings']]],
  ['m_5fscale_5f16gs_50',['M_SCALE_16GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937adf18f57ef6f8ccd9bb76fbde4b297273',1,'MagSettings']]],
  ['m_5fscale_5f4gs_51',['M_SCALE_4GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937a9d366d9106c7315b5409eadcc4598eaa',1,'MagSettings']]],
  ['m_5fscale_5f8gs_52',['M_SCALE_8GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937ad821c54da551fa925d731f944ece29c4',1,'MagSettings']]],
  ['maddress_53',['mAddress',['../structDeviceSettings.html#a6ebf17f9c5fb6be2956964bce95f04f5',1,'DeviceSettings']]],
  ['magavailable_54',['magAvailable',['../classLSM9DS1.html#a6e638bfef3ba1316ba9a35e2b7d77bf6',1,'LSM9DS1']]],
  ['magoffset_55',['magOffset',['../classLSM9DS1.html#a0d461614bd058b082c94481dc916c18b',1,'LSM9DS1']]],
  ['magsettings_56',['MagSettings',['../structMagSettings.html',1,'']]],
  ['mx_57',['mx',['../structLSM9DS1Sample.html#a4bd4a25247e97565ab1ef9c3f1450dff',1,'LSM9DS1Sample']]],
  ['my_58',['my',['../structLSM9DS1Sample.html#a97863976642da1e77344be774d71da30',1,'LSM9DS1Sample']]],
  ['mz_59',['mz',['../structLSM9DS1Sample.html#aa0891a22db3ce7348015fa152a04d223',1,'LSM9DS1Sample']]]
];
