var searchData=
[
  ['m_5fscale_5f12gs_144',['M_SCALE_12GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937af5a22d2dff6ca6006a6bda427fd7b8ff',1,'MagSettings']]],
  ['m_5fscale_5f16gs_145',['M_SCALE_16GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937adf18f57ef6f8ccd9bb76fbde4b297273',1,'MagSettings']]],
  ['m_5fscale_5f4gs_146',['M_SCALE_4GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937a9d366d9106c7315b5409eadcc4598eaa',1,'MagSettings']]],
  ['m_5fscale_5f8gs_147',['M_SCALE_8GS',['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937ad821c54da551fa925d731f944ece29c4',1,'MagSettings']]]
];
