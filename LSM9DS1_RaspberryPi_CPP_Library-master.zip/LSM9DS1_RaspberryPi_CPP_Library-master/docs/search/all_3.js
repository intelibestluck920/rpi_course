var searchData=
[
  ['devicesettings_17',['DeviceSettings',['../structDeviceSettings.html',1,'']]],
  ['drdy_5fgpio_18',['drdy_gpio',['../structDeviceSettings.html#a08665452b221df61305d7e01f6df8a8c',1,'DeviceSettings']]]
];
