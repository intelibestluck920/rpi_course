var searchData=
[
  ['samplerate_128',['SampleRate',['../structGyroSettings.html#a056358d9bfbc274f537c64ad59f015f7',1,'GyroSettings::SampleRate()'],['../structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3a',1,'MagSettings::SampleRate()']]],
  ['scale_129',['Scale',['../structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642d',1,'AccelSettings::Scale()'],['../structGyroSettings.html#ad4b72cfc7b1b3314f59818df6692e2e2',1,'GyroSettings::Scale()'],['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937',1,'MagSettings::Scale()']]]
];
