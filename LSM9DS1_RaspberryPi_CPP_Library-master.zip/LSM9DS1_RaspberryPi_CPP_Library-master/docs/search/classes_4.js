var searchData=
[
  ['magsettings_79',['MagSettings',['../structMagSettings.html',1,'']]]
];
