var searchData=
[
  ['samplerate_123',['sampleRate',['../structGyroSettings.html#a922ffe8bd100784d5d46191e49d6949c',1,'GyroSettings::sampleRate()'],['../structMagSettings.html#a77ce5bc663dadc1f5cc656a6721946a1',1,'MagSettings::sampleRate()']]],
  ['scale_124',['scale',['../structAccelSettings.html#a26da12d9d6e545a3cb70bd6f4fbabffe',1,'AccelSettings::scale()'],['../structGyroSettings.html#ad619c27e693000f0cfff5410a970c490',1,'GyroSettings::scale()']]]
];
