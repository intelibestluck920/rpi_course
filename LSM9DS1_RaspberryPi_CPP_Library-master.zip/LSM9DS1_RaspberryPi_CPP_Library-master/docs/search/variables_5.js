var searchData=
[
  ['i2c_5fbus_117',['i2c_bus',['../structDeviceSettings.html#a97fd48d0494d77bfe3518646cace6fc3',1,'DeviceSettings']]],
  ['initpigpio_118',['initPIGPIO',['../structDeviceSettings.html#a7eeb6da1658e07a25b4dcd4d97318581',1,'DeviceSettings']]]
];
