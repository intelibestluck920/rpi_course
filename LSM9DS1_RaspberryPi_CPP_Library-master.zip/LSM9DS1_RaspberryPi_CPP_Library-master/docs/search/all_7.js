var searchData=
[
  ['i2c_5fbus_43',['i2c_bus',['../structDeviceSettings.html#a97fd48d0494d77bfe3518646cace6fc3',1,'DeviceSettings']]],
  ['i2c_20lsm9ds1_20raspberrypi_20c_2b_2b_20library_44',['I2C LSM9DS1 RaspberryPI C++ Library',['../index.html',1,'']]],
  ['initpigpio_45',['initPIGPIO',['../structDeviceSettings.html#a7eeb6da1658e07a25b4dcd4d97318581',1,'DeviceSettings']]]
];
