var searchData=
[
  ['magavailable_95',['magAvailable',['../classLSM9DS1.html#a6e638bfef3ba1316ba9a35e2b7d77bf6',1,'LSM9DS1']]],
  ['magoffset_96',['magOffset',['../classLSM9DS1.html#a0d461614bd058b082c94481dc916c18b',1,'LSM9DS1']]]
];
