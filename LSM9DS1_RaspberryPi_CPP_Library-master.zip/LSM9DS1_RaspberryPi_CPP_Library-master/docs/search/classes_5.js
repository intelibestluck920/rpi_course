var searchData=
[
  ['temperaturesettings_80',['TemperatureSettings',['../structTemperatureSettings.html',1,'']]]
];
