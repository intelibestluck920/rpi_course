var searchData=
[
  ['devicesettings_74',['DeviceSettings',['../structDeviceSettings.html',1,'']]]
];
