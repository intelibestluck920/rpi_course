var searchData=
[
  ['xyperformance_126',['XYPerformance',['../structMagSettings.html#a774456200b5a527eef05a195dd44ed94',1,'MagSettings']]]
];
