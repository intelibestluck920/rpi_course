var searchData=
[
  ['samplerate_63',['SampleRate',['../structGyroSettings.html#a056358d9bfbc274f537c64ad59f015f7',1,'GyroSettings::SampleRate()'],['../structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3a',1,'MagSettings::SampleRate()'],['../structGyroSettings.html#a922ffe8bd100784d5d46191e49d6949c',1,'GyroSettings::sampleRate()'],['../structMagSettings.html#a77ce5bc663dadc1f5cc656a6721946a1',1,'MagSettings::sampleRate()']]],
  ['scale_64',['scale',['../structAccelSettings.html#a26da12d9d6e545a3cb70bd6f4fbabffe',1,'AccelSettings::scale()'],['../structGyroSettings.html#ad619c27e693000f0cfff5410a970c490',1,'GyroSettings::scale()'],['../structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642d',1,'AccelSettings::Scale()'],['../structGyroSettings.html#ad4b72cfc7b1b3314f59818df6692e2e2',1,'GyroSettings::Scale()'],['../structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937',1,'MagSettings::Scale()']]],
  ['setaccelscale_65',['setAccelScale',['../classLSM9DS1.html#acaee2a632dde4e2d9d3ecbd1cbebf4fe',1,'LSM9DS1']]],
  ['setcallback_66',['setCallback',['../classLSM9DS1.html#a3102ea02c253af39e3b43ee55b94d716',1,'LSM9DS1']]],
  ['setgyroscale_67',['setGyroScale',['../classLSM9DS1.html#a71abda68a516580bf911c1c9b0d24643',1,'LSM9DS1']]],
  ['setmagscale_68',['setMagScale',['../classLSM9DS1.html#a6aeb6f61c0ab1f2ce72450850241dc04',1,'LSM9DS1']]]
];
