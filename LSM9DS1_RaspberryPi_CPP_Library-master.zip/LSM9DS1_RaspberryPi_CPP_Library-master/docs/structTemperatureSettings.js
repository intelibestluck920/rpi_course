var structTemperatureSettings =
[
    [ "enabled", "structTemperatureSettings.html#a57df0249518b1ddf0f0ae455c22467fd", null ]
];