var annotated_dup =
[
    [ "AccelSettings", "structAccelSettings.html", "structAccelSettings" ],
    [ "DeviceSettings", "structDeviceSettings.html", "structDeviceSettings" ],
    [ "GyroSettings", "structGyroSettings.html", "structGyroSettings" ],
    [ "LSM9DS1", "classLSM9DS1.html", "classLSM9DS1" ],
    [ "LSM9DS1callback", "classLSM9DS1callback.html", "classLSM9DS1callback" ],
    [ "LSM9DS1Sample", "structLSM9DS1Sample.html", "structLSM9DS1Sample" ],
    [ "MagSettings", "structMagSettings.html", "structMagSettings" ],
    [ "TemperatureSettings", "structTemperatureSettings.html", "structTemperatureSettings" ]
];