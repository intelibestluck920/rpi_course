var structAccelSettings =
[
    [ "Abw", "structAccelSettings.html#a7a8df1b6f8b4041c96c613bfee1da18f", [
      [ "A_ABW_408", "structAccelSettings.html#a7a8df1b6f8b4041c96c613bfee1da18face51d69b84b07ca405f72bed13a9731e", null ],
      [ "A_ABW_211", "structAccelSettings.html#a7a8df1b6f8b4041c96c613bfee1da18faa89beb086506101f873c3804c0f10ee6", null ],
      [ "A_ABW_105", "structAccelSettings.html#a7a8df1b6f8b4041c96c613bfee1da18fa42b7213c91bb092ad6d6928d3222a3dd", null ],
      [ "A_ABW_50", "structAccelSettings.html#a7a8df1b6f8b4041c96c613bfee1da18fa2b3e8f727828e6ad4cdc923343da9ef1", null ],
      [ "A_ABW_OFF", "structAccelSettings.html#a7a8df1b6f8b4041c96c613bfee1da18faca0957c2947daa5c4a37b488c3d095c8", null ]
    ] ],
    [ "Scale", "structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642d", [
      [ "A_SCALE_2G", "structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642da8e8c12079c985cf15b37bbf0ed45ead7", null ],
      [ "A_SCALE_16G", "structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642da9b0b8f22efaa1d243a85962f7288ce6f", null ],
      [ "A_SCALE_4G", "structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642da45482a898abc8da9e570b6859f80b182", null ],
      [ "A_SCALE_8G", "structAccelSettings.html#ac0ff203344487d5f3e1ddd5fab15642da9acc54364244cf6a74f8d04597bffe8b", null ]
    ] ],
    [ "bandwidth", "structAccelSettings.html#aae3fa029e37e6b86fa9d36f6bc38eda9", null ],
    [ "enableX", "structAccelSettings.html#a8bf34ff635af7dbf3092a97f69553ebc", null ],
    [ "enableY", "structAccelSettings.html#a08a80d20c2097924b886d7b33a3ced13", null ],
    [ "enableZ", "structAccelSettings.html#ada2c1a0b933519b3a31c5949776eb4d1", null ],
    [ "highResBandwidth", "structAccelSettings.html#ad954a137d5a713271e03e6fe3a7b5e12", null ],
    [ "highResEnable", "structAccelSettings.html#a74a1c9d4aa1b6d22401c8a2953d07fd9", null ],
    [ "scale", "structAccelSettings.html#a26da12d9d6e545a3cb70bd6f4fbabffe", null ]
];