var files_dup =
[
    [ "LSM9DS1.h", "LSM9DS1_8h_source.html", null ],
    [ "LSM9DS1_Registers.h", "LSM9DS1__Registers_8h_source.html", null ],
    [ "LSM9DS1_Types.h", "LSM9DS1__Types_8h_source.html", null ]
];