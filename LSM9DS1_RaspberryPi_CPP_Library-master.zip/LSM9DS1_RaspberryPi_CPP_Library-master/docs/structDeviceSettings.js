var structDeviceSettings =
[
    [ "agAddress", "structDeviceSettings.html#a7328dff74d5f28e777fc433ed90025bf", null ],
    [ "drdy_gpio", "structDeviceSettings.html#a08665452b221df61305d7e01f6df8a8c", null ],
    [ "i2c_bus", "structDeviceSettings.html#a97fd48d0494d77bfe3518646cace6fc3", null ],
    [ "initPIGPIO", "structDeviceSettings.html#a7eeb6da1658e07a25b4dcd4d97318581", null ],
    [ "mAddress", "structDeviceSettings.html#a6ebf17f9c5fb6be2956964bce95f04f5", null ]
];