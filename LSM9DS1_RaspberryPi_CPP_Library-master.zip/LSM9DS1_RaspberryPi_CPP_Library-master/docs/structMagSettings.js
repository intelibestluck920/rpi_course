var structMagSettings =
[
    [ "SampleRate", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3a", [
      [ "M_ODR_0625", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aacc660f92c5c11995b3f0d9695fc73168", null ],
      [ "M_ODR_125", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aab2f6d929439957370f088b40e5ec2170", null ],
      [ "M_ODR_250", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aa0768ce00d1325ad6d54f16fe75146082", null ],
      [ "M_ODR_5", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aa4bf6562bc571bf08a9353f7efdd28018", null ],
      [ "M_ODR_10", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aaa8dcecf2bafd5b44328ae4ef8921b3bb", null ],
      [ "M_ODR_20", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aa659c640459e4c86b47f320be711026be", null ],
      [ "M_ODR_40", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aa709b67abb55cfaee81ceda1909764847", null ],
      [ "M_ODR_80", "structMagSettings.html#aae6fd3e8779a9e8f77c290148c2eea3aa679dd3f1e025c36f9222ad471fd19a1e", null ]
    ] ],
    [ "Scale", "structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937", [
      [ "M_SCALE_4GS", "structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937a9d366d9106c7315b5409eadcc4598eaa", null ],
      [ "M_SCALE_8GS", "structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937ad821c54da551fa925d731f944ece29c4", null ],
      [ "M_SCALE_12GS", "structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937af5a22d2dff6ca6006a6bda427fd7b8ff", null ],
      [ "M_SCALE_16GS", "structMagSettings.html#a77cd563fbb237f628d0b9e95206e5937adf18f57ef6f8ccd9bb76fbde4b297273", null ]
    ] ],
    [ "enabled", "structMagSettings.html#a308c561165a1fa96fd780f8ee36ae749", null ],
    [ "lowPowerEnable", "structMagSettings.html#ad643bfdfae58f7b1146e5d22fb5720e4", null ],
    [ "sampleRate", "structMagSettings.html#a77ce5bc663dadc1f5cc656a6721946a1", null ],
    [ "scale", "structMagSettings.html#aa8429bbbdc0670f4a3c9dff07545d856", null ],
    [ "tempCompensationEnable", "structMagSettings.html#a2d07cb80ac268bec5e96c56d551439b7", null ],
    [ "XYPerformance", "structMagSettings.html#a774456200b5a527eef05a195dd44ed94", null ],
    [ "ZPerformance", "structMagSettings.html#a8d5f1e42ab6234c913dbc145ba6aa619", null ]
];