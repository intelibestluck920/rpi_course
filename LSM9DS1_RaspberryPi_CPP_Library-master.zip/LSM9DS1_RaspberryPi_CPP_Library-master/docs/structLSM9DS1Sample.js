var structLSM9DS1Sample =
[
    [ "ax", "structLSM9DS1Sample.html#ac8489a5f20b1fbd76e1ea3d16d83b452", null ],
    [ "ay", "structLSM9DS1Sample.html#aff834c5334cf93ec59bb6e7fd65168d1", null ],
    [ "az", "structLSM9DS1Sample.html#af4dafbb6b5868703de9049217fad30e2", null ],
    [ "gx", "structLSM9DS1Sample.html#a30b5bda7940cec19db9da99b0a419f37", null ],
    [ "gy", "structLSM9DS1Sample.html#a403a6077e7f0e34f5b9901ebb582aa3e", null ],
    [ "gz", "structLSM9DS1Sample.html#ae39ba34a5abfb51dcb60161bbacc1a24", null ],
    [ "mx", "structLSM9DS1Sample.html#a4bd4a25247e97565ab1ef9c3f1450dff", null ],
    [ "my", "structLSM9DS1Sample.html#a97863976642da1e77344be774d71da30", null ],
    [ "mz", "structLSM9DS1Sample.html#aa0891a22db3ce7348015fa152a04d223", null ],
    [ "temperature", "structLSM9DS1Sample.html#a638457f71377b81f6dd9389c26b467dc", null ]
];