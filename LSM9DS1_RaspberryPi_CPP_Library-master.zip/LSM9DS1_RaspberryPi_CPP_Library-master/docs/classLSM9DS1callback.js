var classLSM9DS1callback =
[
    [ "hasSample", "classLSM9DS1callback.html#afbed455bfdd46ee74432533ad3c93683", null ]
];